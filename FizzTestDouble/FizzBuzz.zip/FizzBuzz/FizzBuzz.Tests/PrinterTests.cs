using System;
using FluentAssertions;
using Xunit;

namespace FizzBuzz.Tests
{
    public class PrinterTests
    {
        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(32)]
        [InlineData(64)]
        public void numbers_from_1_to_100_are_shown(int number)
        {
            //Arrange
            var sut = new Printer();
            
            // Act
            var print = sut.Print(number);
            
            //Assert
            print.Should().Be(number.ToString());
        }

        [Theory]
        [InlineData(3, "Fizz")]
        [InlineData(9, "Fizz")]
        void Multiple_of_thee_print_Fizz(int number, string expected)
        {
            var sut = new Printer();

            sut.Print(number).Should().Be(expected);
        }
        
        [Theory]
        [InlineData(5, "Buzz")]
        [InlineData(50, "Buzz")]
        void Multiple_of_five_print_Buzz(int number, string expected)
        {
            var sut = new Printer();

            sut.Print(number).Should().Be(expected);
        }

        [Theory]
        [InlineData(15, "FizzBuzz")]
        [InlineData(30, "FizzBuzz")]
        void Multiple_of_five_and_three_print_FizzBuzz(int number, string expected)
        {
            var sut = new Printer();

            sut.Print(number).Should().Be(expected);
        }
        
        [Theory]
        [InlineData(2, "2")]
        [InlineData(34, "34")]
        void Not_multiple_print_the_number_itself(int number, string expected)
        {
            var sut = new Printer();

            sut.Print(number).Should().Be(expected);
        }

        [Theory]
        [InlineData(101)]
        [InlineData(0)]
        void outside_Border_values_throws_exception(int number)
        {
            var sut = new Printer();
            
            sut.Invoking( x => x.Print(number)).Should().Throw<Exception>();
        }

    }
}