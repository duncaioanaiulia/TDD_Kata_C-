﻿using NSubstitute;
using Xunit;

namespace FizzBuzz.Tests
{
    public class FizzBuzzRunnerScenario
    {
        [Fact]
        void FizzBuzzRunner_uses_NumberCounter_to_generate_numbers()
        {
            //Arrange
            var numberCounter = Substitute.For<INumberCounter>();
            var printer = Substitute.For<IPrinter>();
            
            var sut = new FizzBuzzRunner(numberCounter, printer);
        
            //Act
            sut.Run();
            
            //Assert
            numberCounter.Received().GenerateFrom(1, 100);

        }

        [Fact]
        void FizzBuzzRunner_pass_generate_numbers_to_Printer()
        {
            var numberCounter = Substitute.For<INumberCounter>();
            var printer = Substitute.For<IPrinter>();

            numberCounter.GenerateFrom(1, 100).Returns(new[] {1});
            
            var sut = new FizzBuzzRunner(numberCounter, printer);

            sut.Run();

            printer.Received().Print(1);

        }
    }

    internal class FizzBuzzRunner
    {
        readonly INumberCounter _numberCounter;
        readonly IPrinter _printer;

        public FizzBuzzRunner(INumberCounter numberCounter, IPrinter printer)
        {
            _numberCounter = numberCounter;
            _printer = printer;
        }

        public void Run()
        {
            var list =_numberCounter.GenerateFrom(1, 100);

            foreach (var number in list)
            {
                _printer.Print(number);
            }
        }
    }
}