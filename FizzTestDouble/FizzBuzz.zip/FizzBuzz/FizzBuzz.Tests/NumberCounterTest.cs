﻿using FluentAssertions;
using Xunit;

namespace FizzBuzz.Tests
{
    public class NumberCounterTest
    {
        [Fact]
        void Iterate_from_numbers_starting_from_a_given_starting_point()
        {
            var sut = new NumberCounter();

            var actual = sut.GenerateFrom(1, 100);

            actual.Should().HaveCount(100);
        }
    }
}