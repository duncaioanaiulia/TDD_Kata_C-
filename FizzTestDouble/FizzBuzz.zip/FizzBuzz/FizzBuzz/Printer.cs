﻿using System;

namespace FizzBuzz
{
    public interface IPrinter
    {
        string Print(int number);
    }

    public class Printer : IPrinter
    {
        public string Print(int number)
        {
            if (number <= 0 || number > 100)
                throw new Exception("Test");
                
            var three = number % 3 == 0;
            var five = number % 5 == 0;
            if (three && five)
                return "FizzBuzz";
            if (three)
                return "Fizz";
            if (five)
                return "Buzz";

            return number.ToString();
        }
    }
}