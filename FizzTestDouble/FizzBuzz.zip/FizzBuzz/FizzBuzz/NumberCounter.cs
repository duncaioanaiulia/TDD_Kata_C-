﻿using System.Collections.Generic;
using System.Linq;

namespace FizzBuzz
{
    public interface INumberCounter
    {
        IEnumerable<int> GenerateFrom(int start, int count);
    }

    public class NumberCounter : INumberCounter
    {
        public IEnumerable<int> GenerateFrom(int start, int count) => Enumerable.Range(start, count);
    }
}